from reg_lunatic import *
from importlib import import_module
from reg_lunatic.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("reg_lunatic.modules." + module_name)
bot.run_until_disconnected()

usr.local.bin

